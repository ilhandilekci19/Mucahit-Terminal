import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import os
import shutil
import winreg
import sys

# -*- coding: utf-8 -*-

class MucahitKurulum:
    def __init__(self, root):
        self.root = root
        self.root.title("Mücahit Dili Kurulum Yardımcısı")
        
        # --- ÜST BAR İKONU İÇİN GARANTİ YÖNTEM ---
        try:
            # 1. Yöntem: .ico dosyası ile (En profesyoneli)
            if os.path.exists("logo.ico"):
                self.root.iconbitmap("logo.ico")
            
            # 2. Yöntem (Yedek): .ico yemezse .png dosyasını ikon yap
            elif os.path.exists("logo.png"):
                icon_img = ImageTk.PhotoImage(file="logo.png")
                self.root.wm_iconphoto(True, icon_img)
        except Exception as e:
            print(f"İkon yükleme hatası: {e}")
            
        self.root.geometry("500x550")
        self.root.resizable(False, False)
        self.root.configure(bg="white")

        self.varsayilan_yol = os.path.join(os.path.expanduser("~"), ".vscode", "extensions")
        self.hedef_yol = tk.StringVar(value=self.varsayilan_yol)

        self.ana_ekran()

    def temizle(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def ana_ekran(self):
        self.temizle()
        try:
            self.img = Image.open("logo.png")
            self.img = self.img.resize((150, 150), Image.Resampling.LANCZOS)
            self.logo = ImageTk.PhotoImage(self.img)
            tk.Label(self.root, image=self.logo, bg="white").pack(pady=20)
        except:
            tk.Label(self.root, text="[ MC. ]", font=("Arial", 24, "bold"), bg="white", fg="blue").pack(pady=20)

        tk.Label(self.root, text="Mücahit Programlama Dili", font=("Arial", 18, "bold"), fg="#2c3e50", bg="white").pack(pady=10)
        tk.Label(self.root, text="Kurulum Yardımcısına Hoş Geldiniz.", font=("Arial", 12), bg="white").pack(pady=5)
        tk.Label(self.root, text="Bu sihirbaz, Mücahit dilini kuracak ve\n.mc dosyalarını logonuzla eşleştirecektir.", justify="center", bg="white").pack(pady=20)
        
        tk.Button(self.root, text="Devam Et", command=self.yol_secim_ekrani, width=15, bg="#27ae60", fg="white", font=("Arial", 10, "bold"), cursor="hand2").pack(side="bottom", pady=30)

    def yol_secim_ekrani(self):
        self.temizle()
        tk.Label(self.root, text="Kurulum Yolu Belirle", font=("Arial", 14, "bold"), bg="white").pack(pady=20)
        tk.Label(self.root, text="Eklentinin kurulacağı klasörü seçiniz:", bg="white").pack(pady=5)
        yol_cerceve = tk.Frame(self.root, bg="white")
        yol_cerceve.pack(pady=10)
        tk.Entry(yol_cerceve, textvariable=self.hedef_yol, width=45).pack(side="left", padx=5)
        tk.Button(yol_cerceve, text="Gözat", command=self.yol_degistir, cursor="hand2").pack(side="left")
        tk.Button(self.root, text="Kurulumu Başlat", command=self.kurulumu_yap, width=15, bg="#27ae60", fg="white", font=("Arial", 10, "bold"), cursor="hand2").pack(side="bottom", pady=30)

    def yol_degistir(self):
        secilen = filedialog.askdirectory()
        if secilen: self.hedef_yol.set(secilen)

    def ikon_ata(self, hedef_klasor):
        try:
            # İkonun kalıcı yolu
            ikon_yolu = os.path.join(hedef_klasor, "logo.ico").replace("/", "\\")
            
            # 1. Uzantıyı oluştur
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\.mc") as key:
                winreg.SetValue(key, "", winreg.REG_SZ, "MucahitCodeFile")
            
            # 2. Dosya tipini ve ikonu tanımla
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\MucahitCodeFile\DefaultIcon") as key:
                winreg.SetValue(key, "", winreg.REG_SZ, ikon_yolu)
            
            # 3. Sistemi tazele
            import ctypes
            ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)
        except Exception as e:
            print(f"İkon atama hatası: {e}")

    def kurulumu_yap(self):
        kaynak = os.path.join(os.getcwd(), "tr-dili")
        hedef = os.path.join(self.hedef_yol.get(), "tr-dili")

        try:
            if not os.path.exists(kaynak):
                messagebox.showerror("Hata", "Kaynak 'tr-dili' klasörü bulunamadı!")
                return

            if os.path.exists(hedef): shutil.rmtree(hedef)
            shutil.copytree(kaynak, hedef)
            
            self.ikon_ata(hedef)
            self.bitis_ekrani()
        except Exception as e:
            messagebox.showerror("Kurulum Hatası", f"Hata: {e}")

    def bitis_ekrani(self):
        self.temizle()
        tk.Label(self.root, text="Kurulum Tamamlandı!", font=("Arial", 16, "bold"), fg="#27ae60", bg="white").pack(pady=40)
        tk.Label(self.root, text="Mücahit dili ve .mc dosya ikonları başarıyla yüklendi.\nVS Code'u yeniden başlatmayı unutmayın.", justify="center", bg="white").pack(pady=10)
        tk.Button(self.root, text="Bitir", command=self.root.quit, width=15, bg="#2980b9", fg="white", font=("Arial", 10, "bold"), cursor="hand2").pack(side="bottom", pady=30)

if __name__ == "__main__":
    root = tk.Tk()
    app = MucahitKurulum(root)
    root.mainloop()