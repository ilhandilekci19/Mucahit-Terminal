const vscode = require('vscode');
const path = require('path');

function activate(context) {
    // Komut adını package.json'daki ile aynı yaptık: mucahit.calistir
    let disposable = vscode.commands.registerCommand('mucahit.calistir', function () {
        const editor = vscode.window.activeTextEditor;
        if (editor) {
            const dosyaYolu = editor.document.fileName;
            
            // Dosyanın .mc uzantılı olduğundan emin olalım
            if (!dosyaYolu.endsWith('.mc')) {
                vscode.window.showErrorMessage('Hata: Sadece .mc uzantılı Mücahit dosyaları çalıştırılabilir!');
                return;
            }

            // Terminal oluştur veya var olanı al
            const terminal = vscode.window.activeTerminal || vscode.window.createTerminal("Mücahit Terminal");
            
            // Dosyayı otomatik kaydet (çalıştırmadan önce değişiklikler kaybolmasın)
            editor.document.save().then(() => {
                terminal.show();
                // Burada doğrudan 'mücahit' komutunu kullanıyoruz (çünkü .bat dosyan hazır)
                terminal.sendText(`mücahit "${dosyaYolu}"`);
            });
        }
    });

    context.subscriptions.push(disposable);
}

function deactivate() {}

module.exports = {
    activate,
    deactivate
}