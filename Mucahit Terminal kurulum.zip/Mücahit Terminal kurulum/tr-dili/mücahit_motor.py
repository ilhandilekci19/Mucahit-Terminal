import sys
import os
import re

hafiza = {}
renkler = {"kırmızı": "\033[91m", "yeşil": "\033[92m", "sarı": "\033[93m", "mavi": "\033[94m", "mor": "\033[95m", "sıfır": "\033[0m"}

def calistir(dosya_yolu):
    # Dosya uzantı kontrolü (.mc mi?)
    if not dosya_yolu.endswith(".mc"):
        print("\033[91mHATA: Bu bir Mücahit (.mc) dosyası değil!\033[0m")
        return

    try:
        dosya_adi = os.path.basename(dosya_yolu)
        kapanis_komutu = f"bitti.{dosya_adi}" # Örn: bitti.deneme.mc
        
        with open(dosya_yolu, "r", encoding="utf-8") as f:
            ham_satirlar = [s.strip() for s in f.readlines() if s.strip()]
        
        # --- MÜHÜR KONTROLÜ ---
        if kapanis_komutu not in ham_satirlar:
            print(f"\033[91mHATA: '{kapanis_komutu}' mühürü dosyada bulunamadı!\033[0m")
            return
            
        if ham_satirlar[-1] != kapanis_komutu:
            print(f"\033[91mHATA: Mühür en son satırda olmalı!\033[0m")
            return

        islenecek_satirlar = ham_satirlar[:-1]

        i = 0
        atla = False
        while i < len(islenecek_satirlar):
            satir = islenecek_satirlar[i]
            if satir.startswith("#"): i += 1; continue

            # --- KOŞUL SİSTEMİ ---
            if satir == "değilse":
                atla = not atla
                i += 1; continue
            if atla:
                atla = False
                i += 1; continue
            
            # Eğer
            eger_m = re.match(r'eğer\s*\(([a-zA-Zçğüöşİ_]+)\s*==\s*(\(".*"\)|\d+)\)', satir)
            if eger_m:
                var, val = eger_m.groups()
                val = val[2:-2] if val.startswith('("') else int(val)
                atla = not (str(hafiza.get(var)) == str(val))
                i += 1; continue

            # --- TEKRAR ---
            tekrar_m = re.match(r'tekrar="(.+)"\((\d+)\)', satir)
            if tekrar_m:
                m, a = tekrar_m.groups()
                for _ in range(int(a)): print(m)
                i += 1; continue

            # --- YAZDIRMA ---
            birlesik_m = re.match(r'terminal_yazdır=\("(.*)"\),\(([a-zA-Zçğüöşİ_]+)\)', satir)
            renk_m = re.match(r'terminal_yazdır=\("(.*)"\)=\("(.*)"\)', satir)
            renk_s = re.match(r'terminal_yazdır=(\d+),\("(.*)"\)', satir)
            std_m = re.match(r'terminal_yazdır\s*\(\s*(.*)\s*\)', satir)

            if birlesik_m:
                m, d = birlesik_m.groups(); print(f"{m} {hafiza.get(d, '')}")
            elif renk_m:
                m, r = renk_m.groups(); print(f"{renkler.get(r, '')}{hafiza.get(m, m)}{renkler['sıfır']}")
            elif renk_s:
                s, r = renk_s.groups(); print(f"{renkler.get(r, '')}{s}{renkler['sıfır']}")
            elif std_m:
                c = std_m.group(1).strip()
                if c in hafiza: print(hafiza[c])
                elif c.startswith('"'): print(c[1:-1])
                else: print(c)

            # --- GİRDİ VE DEĞİŞKEN ---
            metin_g = re.match(r'değişken=kullanıcı_girdi=([a-zA-Zçğüöşİ_]+)=\("(.*)"\)', satir)
            sayi_g = re.match(r'değişken=kullanıcı_girdi=([a-zA-Zçğüöşİ_]+)="([^"]*)"', satir)
            islem_m = re.match(r'değişken=([a-zA-Zçğüöşİ_]+)=([a-zA-Z0-9çİ_]+)([\+\-\*/])([a-zA-Z0-9çİ_]+)', satir)
            degis_m = re.match(r'değişken=([a-zA-Zçİ_]+)=("(.*)"|\d+)', satir)

            if metin_g:
                k, m = metin_g.groups(); hafiza[k] = input(m + " ")
            elif sayi_g:
                k, m = sayi_g.groups(); val = input(m + " "); hafiza[k] = int(val) if val.isdigit() else 0
            elif islem_m:
                h, s1, op, s2 = islem_m.groups()
                v1 = hafiza.get(s1, int(s1) if str(s1).isdigit() else 0)
                v2 = hafiza.get(s2, int(s2) if str(s2).isdigit() else 0)
                if op == '+': hafiza[h] = v1 + v2
                elif op == '-': hafiza[h] = v1 - v2
                elif op == '*': hafiza[h] = v1 * v2
                elif op == '/': hafiza[h] = v1 / v2
            elif degis_m:
                k, _, v = degis_m.groups(); hafiza[k] = v[1:-1] if isinstance(v, str) and v.startswith('"') else int(v)

            i += 1
            
        print(f"\033[96m>>> [Mücahit Yazılım: {dosya_adi} Tamamlandı]\033[0m")
        
    except Exception as e: print(f"SİSTEM HATASI: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 1: calistir(sys.argv[1])